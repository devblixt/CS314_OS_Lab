#!/bin/sh
./fstime.sh &
./syscall.sh &
wait
